==================================
ReadMe.txt
==================================
mIRC DeluXe II - The Lost Version
Release: March 12, 2012

Version LOST_2_TIME
By: Neo Nemesis aka T0x|cAv3ng3r

SYSTEM REQUIREMENTS
mIRC: Version 6.35
DirectX: 9+
Operating System: WINDOWS XP or higher


==================================
DISCLAIMER
==================================
THIS PROGRAM IS FREEWARE AND IS PROVIDED AS IS. THE WRITERS OF THIS mIRC SCRIPT ARE NOT ACCOUNTABLE FOR WHAT IS DONE/DAMAGED 
WITH THIS SCRIPT BY THE USERS. THIS PROGRAM IS PROVIDED AS A 100% GURANTEED VIRUS FREE AND IS 100% OPEN SOURCE. ALL GRAPHICS, 
SOUNDS AND CODE USED IN THIS mIRC SCRIPT MAY BE USED WITHOUT PERMISSION FROM THE WRITERS OF THIS SCRIPT.

THIS SCRIPT HAS BEEN INSPIRED BY NINTENDO'S The Legend of Zelda and other works.

ALL WORKS FEATURED IN THIS SCRIPT BELONG TO THEIR RIGHTFUL OWNERS AND ARE PROVIDED IN THIS SCRIPT FREE OF CHARGE AS FREEWARE.

ERRORS AND BUGS MAY BE ENCOUNTERED WITH THIS SCRIPT, PLEASE POST ALL BUGS AND ERROS IN THE HAWKEE.COM THREAD FOR THIS SCRIPT.

Should mIRC freeze up or get stuck in a loop try using CTRL + BREAK, A error message may or may not pop up in one of either the 
Status Window or the currently active window. Please report any and all problems. Please include any and all error messages that 
pop up.

THIS PROGRAM WAS MADE TO WORK ON mIRC v6.35 WHICH IS COPYRIGHTED AND OWNED BY Khaled Mardem-Bhey, mIRC Co. Ltd. YOU MAY USE THIS
SCRIPT WITH YOUR mIRC BUT WE RECOMMEND THAT YOU REGISTER YOUR mIRC AFTER THE EVALUATION PERIOD ENDS.

mIRC.exe IS NOT PROVIDED WITH THIS SCRIPT

To download a copy of mIRC please visit: http://www.mirc.com/get.php?version=635

To register your copy of mIRC please visit: http://www.mirc.com/register.html

==================================
INSTALLATION INSTRUCTIONS
==================================
1) Open LOSTDX.zip (the file you're reading this ReadMe.txt from)
2) Then, open My Computer
3) Next open C:\
4) Back in the LOSTDX.zip file select the DX2 folder and drag it into C:\
5) Now, open C:\mIRC (you must have mIRC already installed)
6) Right click on mIRC.exe
7) Select Copy
8) Open C:\DX2
9) Right click and select Paste
10) Right click on C:\DX2\mIRC.exe
11) Select Copy
12) Right click on desktop
13) Select "Paste ShortCut"

You're done :)
SINCE THIS IS THE LOST VERSION LITTLE TO NO HELP IS AVAILABLE :(

Thank you all for your use of my previous scripts and I hope you enjoy this one. I finished it about 4 months ago,
but never released it, and tucked it away in my archives. I recently found it, made a few lat minute changes and
released it to you. I am on coder vacation.


Late 2012, early 2013 I will be beginning the production of mIRC DeluXe III or something new??